# Write a Python program that prints the length of a string.
# For example of expected results;
# Input Output Explanation
# "" 0 0 because its empty string
# “Jambo” 5 5 because it has 5 characters
print("...Finding the length of a string...")
word = input("Enter the text to find length for: ")
print("{} {} because is has {} characters".format(len(str(word)), len(str(word)), len(str(word))))