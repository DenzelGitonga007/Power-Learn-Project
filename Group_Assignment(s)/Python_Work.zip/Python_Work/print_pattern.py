# Write a python program that will display the number and its square in the following format.
print("Number \t \t Square")
for x in range(1, 6 + 1):
    print("{}\t \t \t {}".format(x, (x*x)))